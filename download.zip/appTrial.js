  //fodder for app.js file. Space to work out functions before moving them over.

  //document.createElement("div");
  
  //this was a third if statement in the document.onkeydown function
  //if(document.getElementById("textbox").focus && document.getElementById("disableMe")){
  //   console.log("text box focus and disableme exists?");
  //   //setTimeout(function(){document.getElementById("disableMe").disabled = false;}, 400);
  //   //document.getElementById("disableMe").click();
  //   console.log("After");
  // }
  //};
//if (document.querySelectorAll)
//    var clsElements = document.querySelectorAll(".mySpeshalClass");
//else
    // loop through all elements instead


// document.getElementById("textarea").on(function(){}
//   if(event.trigger == keyup){
//     console.log('yay');
//   };
//   });

//var addOnce = once(add, "Task added or alert generated.");

// var event = new Event('sweetAlert');

// // Listen for the event.
// window.addEventListener('sweetAlert', function (e) { console.log("yay")}, false);

// // Dispatch the event.
// //window.dispatchEvent(event);

// window.sweetAlert = function(){
//   console.log(event);
//     var testFunc = function(){console.log("onpopup");
//     testFunc();
//   };
// };

// $(document).on("onkeydown", "disableMe", function() {
//   console.log("disable me exists");
//   if(event.keyCode == 13){
//     if(document.getElementById("disableMe").disabled === true){
//     document.getElementById("disableMe").click();
//     event.preventDefault();
//       };
//     };
//   window.preventDefault();
//   });

// document.getElementById("textbox").onfocus = function(){
//   console.log("textbox focused");
//   if(event.keyCode == 13){
//     event.preventDefault();
//   }
// };
// document.keydown = function(event){
//     if(event.which == "13"){
//         document.getElementById("disableMe").trigger("click");
//         document.getElementById("disableMe").disabled = true;
//         setTimeout(function(){document.getElementById("disableMe").disabled = false;}, 400)
//     }
// };

// document.getElementById("textbox").onkeydown = function(){
//   if(event.keyCode == 13){
//     event.preventDefault();
//     document.getElementById("button1").click();
//     document.getElementById("disableMe").disabled = true;
//     setTimeout(function(){document.getElementById("disableMe").disabled = false;}, 100)
//     //func();
//     //clear();
//     //event.preventDefault();
//     // var node = (event.target) ? event.target : ((event.srcElement) ? event.srcElement : null); 
//     // if(node.type=="text"){return false;}
//     // console.log("Event and return and keydown");
//     // console.log(document.getElementsByClassName("confirm"))//.preventDefault();
//     //console.log(document.getElementById("disableMe"));
//     //document.getElementById("disableMe").class = undefined;//.attribute.disabled = true;
//     //console.log(myList);//myList[0].style.color = "red"; // make the first one red
//     //document.getElementsById("button").preventDefault();
//     return false;
//     //document.getElementById("textbox").preventDefault();
//   };
// };

  // <div class="sweet-alert showSweetAlert visible" tabindex="-1" 
  // data-has-cancel-button="false" 
  // data-allow-ouside-click="false" 
  // data-has-done-function="false" 
  // style="display: block; margin-top: -165px;">
  // <div class="icon error animateErrorIcon" 
  // style="display: block;"><span class="x-mark animateXMark">
  // <span class="line left"></span><span class="line right">
  // </span></span></div>
  // <div class="icon warning" style="display: none;"> 
  // <span class="body"></span> <span class="dot"></span> </div> 
  // <div class="icon info" style="display: none;"></div> 
  // <div class="icon success" style="display: none;">
  // <span class="line tip"></span> <span class="line long"
  // </span> <div class="placeholder"></div> 
  // <div class="fix"></div> </div> <div class="icon custom" 
  // style="display: none;"></div> 
  // <h2>Ooops...</h2><p style="display: block;">Task must have some content.</p>
  // <button class="cancel" tabindex="2" style="display: none;">Cancel</button>
  
  // <button class="confirm" tabindex="1" 
  // style="box-shadow: rgba(174, 222, 244, 0.8) 0px 0px 2px, 
  // rgba(0, 0, 0, 0.0470588) 0px 0px 0px 1px inset; 
  // background-color: rgb(174, 222, 244);">OK</button></div>


//document.getElementById("textbox").onkeydown = function(event) {
  //console.log(event);
  //var refreshIntervalId = setInterval(myWindow.onkeydown, 3000);
  // var e = event;
  // if(e.which == 13) {
  //   add();
  //   //myWindow = window.open();
    //refreshIntervalId(); 
    //document.getElementById("enter").addEventListener()
    //var events = event;
    // console.log("before prevent default")
    // e.preventDefault();
    // console.log("after preventDefault")
    // //console.log("Before trigger");
    //setTimeout(function(){document.unbind(document, "preventDefault"); console.log('yay')}, 500);
    //console.log("After trigger");
  //}
  //console.log("not in if");
  
  // if(e.which == 13){
  //   var func = function(e){console.log("set timeout 5000"); return true};
  //   console.log("before func()");
  //   setTimeout(func(), 5000);
  //   console.log("after func()");
  //   //$(this).unbind('submit').submit()
  //}
//}
//     document.getElementById("clickme").addEventListener("click", function(e) {
//   console.log("you clicked " + e.target);
//   e.preventDefault();
// });
    //setTimeout(function(){event.unbind("onkeydown", preventDefault)}, 2000) 

    // //setTimeout(function(){console.log("HI, I ran add"); add();}, 500);
    // document.getElementById("enter").className = "hold";
    // if (document.getElementById("enter").className === "hold") { 
    //   console.log("Holding is happening.")
    // };

// document.onkeyup = function() {
//   if(event.keyCode == 13) {
//     document.getElementById("enter").className = "on";
//     //clearInterval(refreshIntervalId);
//     };
//   };
//  };

  //console.log(document.getElementById("textarea").value.replace(/\s/g, "").length)
  //if(textarea.value.length > 1 ){//&& textarea.value.replace(/\s/g, "").length > 0){
    //   input.keypress(function(e){
    // if (e.keyCode == 13) return false

  //document.getElementById("button1").click();
  //}
  //document.getElementById("form").reset();  



    // var textarea = document.getElementById("textarea");
    // var form = document.getElementById("form");
    // document.form.textarea.focus();
    // form.reset();
    // document.form.textarea.setSelectionRange(0, 0);
    //textarea.selectionStart=0; 
    //textarea.selectionEnd=0; 
    //resetCursor(document.getElementById("form"));
// function resetCursor(txtElement) { 
//     if (txtElement.setSelectionRange) { 
//         txtElement.focus(); 
//         txtElement.setSelectionRange(0, 0); 
//     } else if (txtElement.createTextRange) { 
//         var range = txtElement.createTextRange();  
//         range.moveStart('character', 0); 
//         range.select(); 
//     } 
//   }
  //   };
  // if(haveTasks){
  // if(document.getElementById("todo") === null){
  //   document.getElementById("todo").remove();
  //   document.getElementById("textarea").reset();
  // };
  // };
  // }



// look for window.event in case event isn't passed in
// if (typeof e == 'undefined' && window.event) { e = window.event; }
// if (e.keyCode == 13)
//   {document.getElementById("button1").click();
//         }

//function(e){
//     if(e.keyCode == 13)
//       {add();
//       };
//   });
//console.log(document.getElementById("textarea"));

// //add a task to the queue
// var add = function(){
//   var sup = document.getElementById("textarea").value;
//   if(!sup){
//         alert("Task must have some content.");
//     } else if (showingCompletedTasks){//add task while showing completed tasks
//         //toggleTasks();
//         showingCompletedTasks = false;
//         wrapper = $("<div >", {
//           "class": "todo",
//           "onclick": "todoCompletedClassSwap();",
//           "text": sup
//           }).appendTo(document.getElementById("container"));
//         document.getElementById("form").reset();
//     } else { //add tasks while showing current tasks
//         wrapper = $("<div >", {
//           "class": "todo",
//           "onclick": "todoCompletedClassSwap();",
//           "text": sup
//           }).appendTo(document.getElementById("container"));
//         document.getElementById("form").reset();
//         console.log(wrapper);
//   }
// };

// var getDivs = function(strClassName, obj){
//   if(obj.className == ".todo"){
//       currentTodos.push($(document));
//     };
//   };

// var testFunc = function(strClassName, obj){
//   var nodes = document.getElementsByClassName("todo");
//   console.log(nodes[i]);
//   for (var i = 0; i < nodes.length; i++) {
//     if(nodes[i]){
//       currentTodos.push(nodes[i]);
//       nodes[i].remove();
//     };
//   };
//   getDivs(strClassName, obj);
//   console.log(currentTodos);
// };

//click on a task to remove it
// var todoCompletedClassSwap = function(){
//   haveCompletedTasks = true;
//   if(event.srcElement.className === "todo"){
//        event.srcElement.className = "completed invisible";
//      } else {
//        event.srcElement.className = "todo invisible"; 
//   };
//to add a class:  element.classList.add("otherclass");
//to delete: element.classList.delete("nameOfClass");
//  previousTodos.push(event.srcElement);
//event.srcElement.remove();
//  console.log(previousTodos);
//};

//click button to remove all tasks and store them in an array
//var elements = document.getElementsByClassName("container");

// var hidePast = function(){
//   var divs = document.getElementsByClassName("completed");
//   for (var name in divs){
//     if(divs[name].className === "completed"){
//       divs[name].className = "completed invisible";;
//     }
//   }
// }
  //var elements = document.getElementsByClassName("container");
  //currentTodos.push(elements);
  //   console.log(elements);
  // for(var i = 0; i < elements.length; i++){
  //   elements[i].srcElement.remove();
  // };
  // for (var key in domPart){
  //     if(domPart.key == ".todo"){
  //       currentTodos.push(document.key);
  //     }
  //     };
  //    console.log(currentTodos);
//}
  // for (var i = 1; i < childrenOfCont.length; i++) {
  //     var content = childrenOfCont[i].childNodes;
  //     console.log(content[0].data);
  //     previousTodos.push(content);
  //   };
  // $("." + "task").remove();
  // console.log(previousTodos);
 
//}

// var nodeTest = function(){
//   for(var i = 0; i < previousTodos.length; i++){
//     console.log(previousTodos[i]);
//     console.log(previousTodos[i][0]["data"]);
//   }
// };

//var revisit = function(){
  // for(var i = 0; i < previousTodos.length; i++){
  //   //console.log(previousTodos[i]);
  //   //console.log(previousTodos[i][0]["data"]);
  //       wrapper = $("<div >", {
  //         "class": "task",
  //         "onclick": "hide();",
  //         "text": previousTodos[i][0]["data"],
  //         }).appendTo(document.getElementById('container'));
  // };
//};
//var numOfTasks = $("#container").children();
//console.log(previousTodos);
  // for (var i = 0; i < numOfTasks; i++) {
  //   previousTodos.push($("." + "task").html());
  //   $("." + "task").remove();
  // };
  //console.log(previousTodos);
  //
//};

// var toggleAllTasks = function(){
//     $(".todo").toggle();
// };

// var toggleCompletedTasks = function(){
//   $(".completed").toggle();
// };

// var toggleNonCompletedTasks = function(){
//   var allTasks = $(".todo");
//   console.log(allTasks);
//   for (var i = 0; i < allTasks.length; i++) {
//     if (allTasks[i].className.split(" ")[1] === "completed"){
//       console.log("happy");
//     };
//   };
// };

// var currentVsCompleted = function(){
//   //_.once(arr, func)
// };


//if showing no completed tasks
//  display word current tasks
// else display previous tasks

//click on a task to remove it
// var hide = function(){
//   var flag = true;
//   var func = function(){
//     if (flag) {
//       // $(event.target).wrap(<del>);
//       // } else {
//       $(event.target).remove();
//   }
//   return func
// };

//Use enter in text field to activate add task
// $("textarea").bind("enterKey", function(e){
//   console.log($(this).trigger("enterKey"))
//     //if(document.getElementById('textarea').length > 1){
//       add();
//     //}
//   });
// $("textarea").keyup(function(e){
//     if(e.keyCode == 13)
//     {
//       $(this).trigger("enterKey");
//     }
// });
//  if(user hits enter){
//    run add function
//  };
////click button to remove all tasks and store them in an array
// var elements = document.getElementsByClassName("container");
// var getDivs = function(strClassName, obj){
//   if(obj.className == ".todo"){
//       currentTodos.push($(document));
//     };
//   };

// var testFunc = function(strClassName, obj){
//   var nodes = document.getElementsByClassName("todo");
//   console.log(nodes[i]);
//   for (var i = 0; i < nodes.length; i++) {
//     if(nodes[i]){
//       currentTodos.push(nodes[i]);
//       nodes[i].remove();
//     };
//   };
//   getDivs(strClassName, obj);
//   console.log(currentTodos);
// };

//to add a class:  element.classList.add("otherclass");
//to delete: element.classList.delete("nameOfClass");
//event.srcElement.remove();
//console.log(completedTodos);